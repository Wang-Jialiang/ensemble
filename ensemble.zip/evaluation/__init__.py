"""
================================================================================
评估模块 (Evaluation Package)
================================================================================

模块化评估包，包含：
- strategies: 集成策略 (mean, voting)
- cka: CKA 相似度计算
- inference: 模型提取与推理
- metrics: MetricsCalculator 指标计算
- checkpoint: Checkpoint 加载器
- corruption_robustness: Corruption 鲁棒性评估
- adversarial: 对抗攻击 (FGSM/PGD) + 对抗鲁棒性评估
- ood: OOD 检测评估
- gradcam: GradCAM 热力图分析
- landscape: Loss Landscape 可视化
- saver: 结果保存
- report: 报告生成
- tta: TTA 测试时数据增强

使用方式:
    from ensemble.evaluation import ReportGenerator, evaluate_adversarial
"""

# 对抗鲁棒性评估
from .adversarial import evaluate_adversarial

# Checkpoint 加载器
from .checkpoint import CheckpointLoader

# CKA 相似度
from .cka import compute_ensemble_cka

# Corruption 鲁棒性评估
from .corruption_robustness import evaluate_corruption

# GradCAM
from .gradcam import (
    GradCAMAnalyzer,
    ModelListWrapper,
)

# 模型推理
from .inference import (
    get_all_models_logits,
    get_models_from_source,
)

# Loss Landscape
from .landscape import ModelDistanceCalculator

# 指标计算器
from .metrics import MetricsCalculator

# OOD 检测
from .ood import evaluate_ood

# 报告生成
from .report import ReportGenerator

# 结果保存
from .saver import ResultsSaver

# 集成策略
from .strategies import ENSEMBLE_STRATEGIES, EnsembleFn, get_ensemble_fn

# TTA 测试时数据增强
from .tta import (
    TTAAugmentor,
    TTAConfig,
    TTAStrategyType,
    create_tta_augmentor_for_dataset,
    get_all_models_logits_with_tta,
)

__all__ = [
    # Strategies
    "ENSEMBLE_STRATEGIES",
    "EnsembleFn",
    "get_ensemble_fn",
    # CKA
    "compute_ensemble_cka",
    # Inference
    "get_models_from_source",
    "get_all_models_logits",
    # Metrics
    "MetricsCalculator",
    # Checkpoint
    "CheckpointLoader",
    # Robustness
    "evaluate_corruption",
    # Adversarial
    "evaluate_adversarial",
    # OOD
    "evaluate_ood",
    # GradCAM
    "GradCAMAnalyzer",
    "ModelListWrapper",
    # Model Distance
    "ModelDistanceCalculator",
    # Reporting
    "ResultsSaver",
    "ReportGenerator",
    # TTA
    "TTAConfig",
    "TTAStrategyType",
    "TTAAugmentor",
    "get_all_models_logits_with_tta",
    "create_tta_augmentor_for_dataset",
]
