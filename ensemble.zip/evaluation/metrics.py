"""
================================================================================
指标计算器模块
================================================================================

包含: MetricsCalculator
"""

import torch
import torch.nn.functional as F

from .cka import compute_ensemble_cka
from .strategies import ENSEMBLE_STRATEGIES, EnsembleFn

# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║ 指标计算器                                                                   ║
# ╚══════════════════════════════════════════════════════════════════════════════╝


class MetricsCalculator:
    """集成模型指标计算器。

    计算各种评估指标，包括：
        - 准确率：集成/个体/Oracle/Top-5
        - 校准：ECE、NLL
        - 多样性：分歧度、JS 散度、CKA
        - 公平性：平衡准确率、基尼系数、EOD

    Attributes:
        num_classes: 分类任务的类别数量。
        ece_metric: 用于计算校准误差的 torchmetrics 实例。
    """

    def __init__(self, num_classes: int, ece_n_bins: int):
        from torchmetrics.classification import CalibrationError

        self.num_classes = num_classes
        self.ece_metric = CalibrationError(
            task="multiclass", num_classes=num_classes, n_bins=ece_n_bins, norm="l1"
        )

    def calculate_all_metrics(
        self,
        all_logits: torch.Tensor,
        targets: torch.Tensor,
        ensemble_fn: EnsembleFn = None,
        all_features: torch.Tensor = None,
    ) -> dict:
        """计算所有评估指标。

        Args:
            all_logits: 所有模型的 logits，形状为 [num_models, num_samples, num_classes]。
            targets: 真实标签，形状为 [num_samples]。
            ensemble_fn: 集成策略函数，默认使用均值聚合。
            all_features: 特征向量，形状为 [num_models, num_samples, feature_dim]，
                用于 CKA 计算，若为 None 则回退到 logits。

        Returns:
            dict: 包含所有计算指标的字典。
        """
        m = {}
        ens_logits = (ensemble_fn or ENSEMBLE_STRATEGIES["mean"])(all_logits)

        # 1. 基础性能与校准
        m.update(self._calc_base_performance(ens_logits, targets, all_logits))

        # 2. 模型多样性与核心不一致性
        m.update(self._calc_diversity(all_logits, all_features))

        # 3. 类别公平性与群体偏见 (最复杂段)
        m.update(self._calc_fairness(ens_logits.argmax(1), targets, all_logits))

        return m

    def _calc_base_performance(self, ens_logits, targets, all_logits):
        """计算基础性能指标。

        Args:
            ens_logits: 集成后的 logits，形状为 [num_samples, num_classes]。
            targets: 真实标签。
            all_logits: 所有模型的 logits。

        Returns:
            dict: 包含 ensemble_acc、nll、ece、avg_individual_acc、oracle_acc。
        """
        ens_preds = ens_logits.argmax(1)
        all_preds = all_logits.argmax(2)
        indiv_accs = (all_preds == targets).float().mean(1) * 100.0

        return {
            "ensemble_acc": 100.0 * (ens_preds == targets).float().mean().item(),
            "nll": F.cross_entropy(ens_logits, targets).item(),
            "ece": self.ece_metric(ens_logits, targets).item(),
            "avg_individual_acc": indiv_accs.mean().item(),
            "oracle_acc": 100.0 * (all_preds == targets).any(0).float().mean().item(),
            "entropy": -torch.sum(
                F.softmax(ens_logits, dim=1)
                * torch.log(F.softmax(ens_logits, dim=1) + 1e-8),
                dim=1,
            )
            .mean()
            .item(),
        }

    def _calc_diversity(self, all_logits, all_features=None):
        """计算预测多样性指标。

        包含 Disagreement（硬不一致性）、JS 散度（软不一致性）和 CKA（表示层多样性）。

        Args:
            all_logits: 所有模型的 logits，形状为 [num_models, num_samples, num_classes]。
            all_features: 特征向量，若为 None 则使用 logits 计算 CKA。

        Returns:
            dict: 包含 disagreement、js_divergence、avg_cka、min_cka、max_cka。
        """
        num_m = all_logits.shape[0]
        all_preds = all_logits.argmax(2)
        all_probs = F.softmax(
            all_logits, dim=2
        )  # [num_models, num_samples, num_classes]

        # 1. Disagreement (硬不一致性 - 基于类别标签)
        pairs = [(i, j) for i in range(num_m) for j in range(i + 1, num_m)]
        dis_val = sum(
            (all_preds[p[0]] != all_preds[p[1]]).float().mean().item() for p in pairs
        )

        # 2. JS 散度 (软不一致性 - 基于概率分布)
        js_val = sum(
            self._js_divergence(all_probs[p[0]], all_probs[p[1]]) for p in pairs
        )

        # 3. CKA (表示层多样性)
        cka_input = all_features if all_features is not None else all_logits
        cka_m = compute_ensemble_cka(cka_input)

        return {
            "disagreement": 100.0 * (dis_val / len(pairs) if pairs else 0.0),
            "js_divergence": js_val / len(pairs) if pairs else 0.0,
            **cka_m,
        }

    def _js_divergence(
        self, p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8
    ) -> float:
        """计算两个概率分布之间的 Jensen-Shannon 散度

        Args:
            p: [num_samples, num_classes] 概率分布
            q: [num_samples, num_classes] 概率分布
            eps: 数值稳定性常数

        Returns:
            平均 JS 散度 (范围: 0 到 ln(2) ≈ 0.693)
        """
        m = 0.5 * (p + q)
        kl_pm = (p * (torch.log(p + eps) - torch.log(m + eps))).sum(dim=1)
        kl_qm = (q * (torch.log(q + eps) - torch.log(m + eps))).sum(dim=1)
        js = 0.5 * (kl_pm + kl_qm)
        return js.mean().item()

    def _calc_fairness(self, ens_preds, targets, all_logits):
        """计算公平性指标集

        本方法包含两类公平性度量：

        【类型1】极小极大公平性 (Minimax Fairness / Subgroup Performance)
            - 关注最差群体的 **绝对性能**
            - 指标: worst_class_acc, bottom_3_class_acc, bottom_5_class_acc
            - 逻辑: 弱势群体准确率提升 → 模型更公平
            - 参考: FAIR-Ensemble

        【类型2】组间差异度量 (Gap-based Metrics)
            - 关注组与组之间的 **相对差距**
            - 指标: eod, fairness_score, acc_gini_coef
            - 逻辑: 组间差距缩小 → 模型更公平
            - 参考: DBDE (SPD/EOD/AOD)
        """
        f = {}
        # 1. 逐类统计（内部使用，不输出）
        class_accs = self._get_per_class_stats(ens_preds, targets)

        valid_accs = torch.tensor([a for a in class_accs if a >= 0])
        if len(valid_accs) > 0:
            # ════════════════════════════════════════════════════════════════
            # 【类型1】极小极大公平性 (Minimax Fairness)
            #   关注最差群体的绝对性能，值越高越公平
            # ════════════════════════════════════════════════════════════════
            f["worst_class_acc"] = valid_accs.min().item()  # 最差类别准确率

            # ════════════════════════════════════════════════════════════════
            # 【类型2】组间差异度量 (Gap-based Metrics)
            #   关注组间差距，值越低越公平
            # ════════════════════════════════════════════════════════════════
            f["balanced_acc"] = valid_accs.mean().item()  # 各类平均准确率
            f["acc_gini_coef"] = self._calc_gini(valid_accs)  # 准确率不平等程度
            f["fairness_score"] = (
                100.0 - (valid_accs.max() - valid_accs.min()).item()
            )  # 100减去最大差距

        # 3. 少数群体探测 (包含两类指标)
        f.update(self._calc_minority_bias(ens_preds, targets, all_logits, class_accs))
        return f

    def _get_per_class_stats(self, ens_preds, targets):
        """计算每个类别的准确率

        Returns:
            List[float]: 每个类别的准确率 (%)，不存在的类别返回 -1.0
        """
        class_accs = []
        for c in range(self.num_classes):
            mask = targets == c
            count = mask.sum().item()
            if count == 0:
                class_accs.append(-1.0)  # 标记不存在的类别
            else:
                correct = ((ens_preds == targets) & mask).sum().item()
                class_accs.append(100.0 * correct / count)
        return class_accs

    def _calc_gini(self, vals):
        """计算基尼系数"""
        if len(vals) <= 1 or vals.sum() == 0:
            return 0.0
        sorted_v = torch.sort(vals)[0]
        n = len(vals)
        indices = torch.arange(1, n + 1, dtype=torch.float32)
        return max(
            0.0,
            (
                (2.0 * (indices * sorted_v).sum() / (n * sorted_v.sum())) - (n + 1) / n
            ).item(),
        )

    def _calc_minority_bias(self, ens_preds, targets, all_logits, class_accs):
        """探测并量化针对少数类别的偏见"""
        res = {}
        counts = torch.tensor(
            [(targets == c).sum().item() for c in range(self.num_classes)]
        )
        if (counts > 0).sum() < 2:
            return res

        # 1. 探测少数与多数群体
        valid_idx = torch.where(counts > 0)[0]
        mini_idx = valid_idx[counts[valid_idx].argmin()].item()
        majo_idx = valid_idx[counts[valid_idx].argmax()].item()

        # ════════════════════════════════════════════════════════════════
        # 【类型2】组间差异度量 (Gap-based)
        #   EOD: 少数类与多数类召回率差距，值越低越公平
        # ════════════════════════════════════════════════════════════════
        mini_rec = class_accs[mini_idx] / 100.0
        majo_rec = class_accs[majo_idx] / 100.0
        res["eod"] = abs(majo_rec - mini_rec) * 100.0

        # ════════════════════════════════════════════════════════════════
        # 【类型1】极小极大公平性 (Minimax Fairness)
        #   Bottom-K: 最弱K个类别的绝对准确率，值越高越公平
        # ════════════════════════════════════════════════════════════════
        all_preds = all_logits.argmax(2)
        res.update(self._calc_bottom_k(all_preds, targets, class_accs))
        return res

    def _calc_bottom_k(self, all_preds, targets, class_accs):
        """【类型1】计算单模型表现最差的 K 个类别的集成表现（Minimax Fairness）"""
        res = {}
        # 计算单模型在各类的平均准确率（用于识别 bottom-k 类别）
        sng_class_accs = torch.tensor(
            [
                (all_preds[:, targets == c] == c).float().mean().item() * 100.0
                if (targets == c).sum() > 0
                else 0.0
                for c in range(self.num_classes)
            ]
        )

        for k in [3, 5]:
            if k > self.num_classes:
                continue
            _, bottom_indices = torch.topk(sng_class_accs, k, largest=False)
            res[f"bottom_{k}_class_acc"] = (
                torch.tensor([class_accs[i] for i in bottom_indices]).mean().item()
            )

        return res
